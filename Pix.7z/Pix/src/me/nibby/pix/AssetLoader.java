package me.nibby.pix;

import java.awt.geom.AffineTransform;
import java.awt.image.AffineTransformOp;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Paths;

import javax.imageio.ImageIO;

import me.nibby.pix.util.Tuple2i;

/**
 * <strong>AssetLoader</strong> provides utilities methods to load game
 * assets. 
 * 
 * @author Kevin Yang
 */
public class AssetLoader {
	
	/**
	 * Loads a bitmap in a specified external directory. 
	 * 
	 * @param ref Path to resource
	 * @return Loaded resource
	 * @throws IOException When path to the resource is invalid and/or resource cannot be loaded
	 */
	public static Bitmap loadExternalBitmap(String ref) throws IOException {
		return loadExternalBitmap(ref, 1.0f);
	}
	
	/**
	 * Loads a bitmap in a specified external directory with custom scaling.
	 * 
	 * @param ref Path to resource
	 * @param scale Scale of resource, 1.0f is normal 1:1 scaling.
	 * @return Loaded resource
	 * @throws IOException When path to the resource is invalid and/or resource cannot be loaded
	 */
	public static Bitmap loadExternalBitmap(String ref, float scale) throws IOException {
		return loadBitmap(Files.newInputStream(Paths.get(ref)), scale);
	}
	
	/**
	 * Loads a bitmap externally or locally through an <strong>InputStream</strong>. This can be used to load assets
	 * within a .jar executable by calling: 
	 * <code>Clazz.class.getResourceAsStream(String res);</code>
	 * 
	 * @param input Data source to stream
	 * @return Loaded resource
	 * @throws IOException When path to the resource is invalid and/or resource cannot be loaded
	 */
	public static Bitmap loadBitmap(InputStream input) throws IOException {
		return loadBitmap(input, 1.0f);
	}
	
	/**
	 * Loads a bitmap externally or locally through an <strong>InputStream</strong> with custom scaling. 
	 * This can be used to load assets within a .jar executable by calling: 
	 * <code>Clazz.class.getResourceAsStream(String res);</code>
	 * 
	 * @param input Data source to stream
	 * @param scale Scale of the resource, 1.0f is 1:1 ratio
	 * @return Loaded resource
	 * @throws IOException When path to the resource is invalid and/or resource cannot be loaded
	 */
	public static Bitmap loadBitmap(InputStream input, float scale) throws IOException {
		BufferedImage img = ImageIO.read(input);
		AffineTransform transform = new AffineTransform();
		transform.scale(scale, scale);
		AffineTransformOp scaleOp = new AffineTransformOp(transform, AffineTransformOp.TYPE_NEAREST_NEIGHBOR);
		int newWidth = (int) ((float) img.getWidth() * scale);
		int newHeight = (int) ((float) img.getHeight() * scale);
		BufferedImage result = scaleOp.filter(img, new BufferedImage(newWidth, newHeight, BufferedImage.TYPE_INT_ARGB));
		return new Bitmap(result);
	}

	/**
	 * Loads a spritesheet in a specified external directory.
	 * 
	 * @param ref Path to resource
	 * @param cellSize Square size of each sub-image within the spritesheet
	 * @return Loaded spritesheet resource
	 * @throws IOException When path to the spritesheet is invalid and/or spritesheet cannot be loaded
	 */
	public static Spritesheet loadExternalSpritesheet(String ref, int cellSize) throws IOException {
		return loadLocalSpritesheet(ref, cellSize, cellSize);
	}

	/**
	 * Loads a spritesheet in a specified external directory with rectangular cell size.
	 * 
	 * @param ref Path to resource
	 * @param cellWidth Width of each sub-image within the spritesheet
	 * @param cellHeight Height of each sub-image within the spritesheet
	 * @return Loaded spritesheet resource
	 * @throws IOException When path to the spritesheet is invalid and/or spritesheet cannot be loaded
	 */
	public static Spritesheet loadLocalSpritesheet(String ref, int cellWidth, int cellHeight) throws IOException {
		return loadLocalSpritesheet(ref, cellWidth, cellHeight, 1.0f);
	}

	/**
	 * Loads a spritesheet in a specified external directory with rectangular cell size and custom scaling.
	 * 
	 * @param ref Path to resource
	 * @param cellWidth Width of each sub-image within the spritesheet
	 * @param cellHeight Height of each sub-image within the spritesheet
	 * @param scale Custom image scaling
	 * @return Loaded spritesheet resource
	 * @throws IOException When path to the spritehseet is invalid and/or spritesheet cannot be loaded
	 */
	public static Spritesheet loadLocalSpritesheet(String ref, int cellWidth, int cellHeight, float scale) throws IOException {
		return loadLocalSpritesheet(ref, cellWidth, cellHeight, scale, new Tuple2i(0, 0), 0, 0);
	}

	/**
	 * Loads a spritesheet in a specified external directory with rectangular cell size, custom scaling and 
	 * gap spacing specifications.
	 * 
	 * @param ref Path to resource
	 * @param cellWidth Width of each sub-image within the spritesheet
	 * @param cellHeight Height of each sub-image within the spritesheet
	 * @param scale Custom image scaling
	 * @param startOffset Initial start x,y offset (if first frame does not start at 0,0) 
	 * @param hGap Horizontal gap in pixels between each frame
	 * @param vGap Vertical gap in pixels between each frame
	 * @return Loaded spritesheet resource
	 * @throws IOException When path to the spritesheet is invalid and/or spritesheet cannot be loaded
	 */
	public static Spritesheet loadLocalSpritesheet(String ref, int cellWidth, int cellHeight, float scale, Tuple2i startOffset, int hGap, int vGap) throws IOException {
		return loadSpritesheet(Files.newInputStream(Paths.get(ref)), cellWidth, cellHeight, scale, startOffset, hGap, vGap);
	}
	
	/**
	 * Loads a spritesheet in an external or local directory.
	 * This can be used to load assets within a .jar executable by calling: 
	 * <code>Clazz.class.getResourceAsStream(String res);</code>
	 *   
	 * @param inputStream Data source to stream
	 * @param cellSize Square size of each sub-image within the spritesheet
	 * @return Loaded spritesheet resource
	 * @throws IOException When path to the spritesheet is invalid or spritesheet cannot be loaded
	 */
	public static Spritesheet loadSpritesheet(InputStream inputStream, int cellSize) throws IOException {
		return loadSpritesheet(inputStream, cellSize, cellSize);
	}

	/**
	 * Loads a spritesheet in an external or local directory with rectangular cell size.
	 * This can be used to load assets within a .jar executable by calling:
	 * <code>Clazz.class.getResourceAsStream(String res);</code>
	 * 
	 * @param inputStream Data source to stream
	 * @param cellWidth Width of each sub-image within the spritesheet
	 * @param cellHeight Height of each sub-image within the spritesheet
	 * @return Loaded spritesheet resource
	 * @throws IOException When path to the spritesheet is invalid and/or spritesheet cannot be loaded
	 */
	public static Spritesheet loadSpritesheet(InputStream inputStream, int cellWidth, int cellHeight) throws IOException {
		return loadSpritesheet(inputStream, cellWidth, cellHeight, 1.0f);
	}

	/**
	 * Loads a spritesheet in an external or local directory with rectangular cell size and custom scaling.
	 * This can be used to load assets within a .jar executable by calling:
	 * <code>Clazz.class.getResourceAsStream(String res);</code>
	 * 
	 * @param inputStream Data source to stream
	 * @param cellWidth Width of each sub-image within the spritesheet
	 * @param cellHeight Height of each sub-image within the spritesheet
	 * @param scale Scale factor of loaded spritesheet, 1.0f is 1:1 ratio.
	 * @return Loaded spritesheet resource
	 * @throws IOException When path to the spritesheet is invalid and/or spritesheet cannot be loaded
	 */
	private static Spritesheet loadSpritesheet(InputStream inputStream, int cellWidth, int cellHeight, float scale) throws IOException {
		return loadSpritesheet(inputStream, cellWidth, cellHeight, scale, new Tuple2i(0, 0), 0, 0);
	}

	/**
	 * Loads a spritesheet in an external or local directory with rectangular cell size, custom scaling and offset specifications.
	 * 
	 * @param inputStream Data source to stream
	 * @param cellWidth Width of each sub-image within the spritesheet
	 * @param cellHeight Height of each sub-image wtihin the spritesheet
	 * @param scale Scale factor of loaded spritesheet, 1.0f is 1:1 ratio
	 * @param startOffset Initial start x,y offset (if first frame does not start at 0,0) 
	 * @param hGap Horizontal gap in pixels between each frame
	 * @param vGap Vertical gap in pixels between each frame
	 * @return Loaded spritesheet resource
	 * @throws IOException When path to the spritesheet is invalid and/or spritesheet cannot be loaded
	 */
	public static Spritesheet loadSpritesheet(InputStream inputStream, int cellWidth, int cellHeight, float scale,
			Tuple2i startOffset, int hGap, int vGap) throws IOException {
		Bitmap bitmap = loadBitmap(inputStream, scale);
		Spritesheet spritesheet = new Spritesheet(bitmap, new Tuple2i(cellWidth, cellHeight), startOffset, vGap, hGap);
		return spritesheet;
	}
}
