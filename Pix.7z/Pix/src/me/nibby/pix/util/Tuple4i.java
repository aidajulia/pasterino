package me.nibby.pix.util;

/**
 * A data unit which stores 4 integers.
 * 
 * @author Kevin Yang
 */
public class Tuple4i {

	public int x, y, w, h;
	
	public Tuple4i(int x, int y, int w, int h) {
		this.x = x;
		this.y = y;
		this.w = w;
		this.h = h;
	}
	
}
