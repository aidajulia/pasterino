package me.nibby.pix.util;

/**
 * A data unit which contains two integers. 
 * 
 * @author Kevin Yang
 */
public class Tuple2i {

	public int x, y;
	
	public Tuple2i(int x, int y) {
		this.x = x;
		this.y = y;
	}
}
