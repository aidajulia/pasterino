package me.nibby.pix.util;

/**
 * A data unit which stores 4 floats.
 * 
 * @author Kevin Yang
 */
public class Tuple4f {

	public float x, y, w, h;
	
	public Tuple4f(float x, float y, float w, float h) {
		this.x = x;
		this.y = y;
		this.w = w;
		this.h = h;
	}
	
	public Tuple4i asTuple4i() {
		return new Tuple4i((int) x, (int) y, (int) w, (int) h);
	}
}
