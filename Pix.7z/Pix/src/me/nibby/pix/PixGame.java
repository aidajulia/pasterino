package me.nibby.pix;

import java.awt.Canvas;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.GraphicsEnvironment;
import java.awt.image.BufferStrategy;
import java.awt.image.VolatileImage;

/**
 * This is the main game engine class that controls the main game loop.
 * 
 * @author MrDeathJockey
 */
public abstract class PixGame extends Canvas implements Runnable {

	private static final long serialVersionUID = 1L;
	
	/** Current game engine state */
	private boolean running = false;
	
	/** Game engine thread */
	private Thread thread;
	
	/** Game render 'canvas' */
	private final RenderContext context;
	
	/** Title of the game to be displayed where applicable */
	private final String title;
	
	/** Graphics scale of the game */
	private final int drawScale;
	
	/** The component dimensions */
	private int viewWidth, viewHeight;
	
	/** Desired FPS performance */
	private int targetFPS = 9999;
	
	/** Displays FPS information per second in terminal */
	private boolean fpsVerbose = true;
	
	/** Number of BufferStrategy to use (higher prevents flicker but slows performance) */
	private int numBuffers = 2;
	
	/** Time elapsed between each frame */
	private double deltaTime = 0d;
	
	/** Input handler */
	private final Input input;
	
	/** Native hardware accelerated canvas image */
	private VolatileImage nativeImage;
	
	/**
	 * Initializes game objects, to be implemented by child classes.
	 */
	public abstract void gameInitialize();
	
	/**
	 * Updates game logic, to be implemented by child classes.
	 * 
	 * @param input Input handler of the engine
	 * @param deltaTime Time elapsed between each frame
	 */
	public abstract void gameUpdate(Input input, double deltaTime);
	
	/**
	 * Renders game objects, to be implemented by child classes
	 * 
	 * @param context Context on which objects are drawn
	 */
	public abstract void gameRender(RenderContext context);
	
	/**
	 * Creates the game engine instance.
	 * 
	 * @param name Name of the game
	 * @param width Width of the component
	 * @param height Height of the component
	 * @param scale Graphics scaling of RenderContext
	 */
	public PixGame(String name, int width, int height, int scale) {
		this.viewWidth = width;
		this.viewHeight = height;
		setMinimumSize(new Dimension(viewWidth, viewHeight));
		setSize(new Dimension(viewWidth, viewHeight));
		
		this.title = name;
		this.drawScale = scale;
		
		context = new RenderContext(width / scale, height / scale);
		input = new Input(this);
		
		setFocusable(true);
		addMouseListener(input);
		addMouseMotionListener(input);
		addKeyListener(input);
	}
	
	@Override
	public void run() {
		init();
		long lastFPSTime = System.currentTimeMillis();
		int fps = 0;
		long then = System.nanoTime();
		double unprocessed = 0d;
		double nsPerFrame = 1000000000.0d / targetFPS;
		while(running) {
			long now = System.nanoTime();
			unprocessed += (now - then) / nsPerFrame;
			deltaTime = unprocessed;
			then = now;
			boolean canRender = false;
			while(unprocessed >= 1) {
				update();
				canRender = true;
				unprocessed = 0;;
			}
			
			try {
				Thread.sleep(1);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			
			if(canRender) {
				render();
				fps++;
			}
			if(fpsVerbose && System.currentTimeMillis() - lastFPSTime > 1000) {
				System.out.printf("%d FPS\n", fps);
				lastFPSTime = System.currentTimeMillis();
				fps = 0;
			}
		
		}
	}
	
	/**
	 * The parent initialization method which handles internal engine
	 * initialization before invoking <pre>gameInitialize()</pre>
	 */
	private void init() {
		BitmapFont.initializeDefaultFont();
		context.setFont(BitmapFont.getDefaultFont());
		gameInitialize();
	}
	
	/**
	 * The parent update method which handles internal engine
	 * object updates before invoking <pre>gameUpdate()</pre>
	 */
	private void update() {
		gameUpdate(input, deltaTime);
		input.update();
	}
	
	/**
	 * The parent render method which handles internal engine
	 * component rendering before invoking <pre>gameRender()</pre>
	 */
	private void render() {
		int cw = context.getWidth(), ch = context.getHeight();
		if(nativeImage == null) {
			nativeImage = GraphicsEnvironment.getLocalGraphicsEnvironment().getDefaultScreenDevice()
					.getDefaultConfiguration().createCompatibleVolatileImage(cw, ch, VolatileImage.TRANSLUCENT);
		}
		
		BufferStrategy bs = this.getBufferStrategy();
		if(bs == null) {
			createBufferStrategy(numBuffers);
			requestFocus();
			return;
		}
		
		Graphics g = bs.getDrawGraphics();
		context.clear();
		gameRender(context);
		
		Graphics2D _g = nativeImage.createGraphics();
		_g.drawImage(context.getImage(), 0, 0, null);
		_g.dispose();
		g.drawImage(nativeImage, 0, 0, getWidth(), getHeight(), null);
		g.dispose();
		bs.show();
	}
	
	/**
	 * Starts the game engine. This should be invoked by a wrapper.
	 */
	protected void start() {
		if(!running) {
			running = true;
			thread = new Thread(this, "pix-engine");
			thread.setPriority(Thread.MAX_PRIORITY);
			thread.start();
		}
	}
	
	/**
	 * Stops the game engine. This should be invoked by a wrapper.
	 */
	protected void stop() {
		if(running) {
			running = false;
		}
	}
	
	/**
	 * 
	 * @return Width of the canvas component
	 */
	public int getViewWidth() {
		return viewWidth;
	}
	
	/**
	 * 
	 * @return Height of the canvas component
	 */
	public int getViewHeight() {
		return viewHeight;
	}
	
	/**
	 * Sets the desired FPS.
	 * 
	 * @param target Desired FPS
	 */
	public void setTargetFps(int target) {
		this.targetFPS = target;
	}
	
	/**
	 * 
	 * @return The current desired FPS
	 */
	public int getTargetFps() {
		return targetFPS;
	}
	
	/**
	 * Sets the output of FPS value per second.
	 * 
	 * @param verbose FPS verbose flag
	 */
	public void setFpsVerbose(boolean verbose) {
		this.fpsVerbose = verbose;
	}
	
	/**
	 * 
	 * @return FPS verbose flag
	 */
	public boolean isFpsVerbose() {
		return fpsVerbose;
	}
	
	
	/**
	 * 
	 * @return The number of BufferStrategy used
	 */
	public int getNumBuffers() {
		return numBuffers;
	}
	
	/**
	 * 
	 * @return Current title of the game
	 */
	public String getTitle() {
		return title;
	}
	
	/**
	 * 
	 * @return Current graphics scale ratio
	 */
	public int getDrawScale() {
		return drawScale;
	}
}
