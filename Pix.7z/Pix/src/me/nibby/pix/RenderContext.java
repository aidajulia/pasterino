package me.nibby.pix;

import java.awt.image.BufferedImage;
import java.awt.image.DataBufferInt;
import java.util.Arrays;

import com.sun.istack.internal.NotNull;

/**
 * This is the heart of the rendering engine. A master BufferImage is created using the ARGB color model
 * with DataBufferInt. Each pixel is rendered onto the screen using the 32-bit integer color model.
 * An image is represented by an array of size width * height, and rendering is accomplished by the
 * transformation of pixel data from bitmap pixel array to the master image.
 *
 * The master image is then draw using Java2D Graphics object onto the canvas. Dimensions for the
 * render context is different to the dimension of the wrapper, but a resize of the wrapper should not
 * update the size of the context. The size of the context refers to the dimensions of the master image.
 *
 * @author Kevin Yang
 */
public class RenderContext {
	
	/** Dimensions for the render context */
	private int width, height;
	
	/** Array of DataBufferInt pixel data linked to the master image */
	private int[] pixels;
	
	/** The master BufferImage that holds all displayed pixel data */
	private BufferedImage image;
	
	/** Currently used font for drawing text */
	private BitmapFont font;
	
	/** Default color to fill the background with */
	private int clearColor = PixColor.toPixelInt(0, 0, 0, 255);
	
	/**
     * Creates a render context with given dimensions.
     *
     * @param width  Width of the context, in pixels
     * @param height Height of the context, in pixels
     */
	public RenderContext(int width, int height) {
		this.width = width;
		this.height = height;
		this.pixels = new int[width * height];
		this.image = new BufferedImage(width, height, BufferedImage.TYPE_INT_ARGB);
		pixels = ((DataBufferInt) image.getRaster().getDataBuffer()).getData();	
	}
	
	public void clear() {
		Arrays.fill(pixels, clearColor);
	}
	
	/**
	 * Draws a given bitmap to the context. Transfers the pixel data from
	 * the bitmap to the specified location on the context.
	 *
	 * @param bitmap Bitmap to be rendered
	 * @param x x co-ordinate on screen
	 * @param y y co-ordinate on screen
	 */
	public void renderBitmap(Bitmap bitmap, int x, int y) {
		renderBitmap(bitmap, x, y, 1.0f);
	}
	
	/**
	 * Draws a given bitmap to the context. In addition, the pixel alpha is
	 * modified to the one provided, giving transparency effects.
	 *
	 * @param bitmap Bitmap to be rendered
	 * @param x x co-ordinate on screen
	 * @param y y co-ordinate on screen
	 * @param alpha Alpha value desired (0f - 1f)
	 */
	public void renderBitmap(Bitmap bitmap, int x, int y, float alpha) {
		renderBitmap(bitmap, x, y, alpha, 1.0f);
	}
	
	/**
	 * Draws a given bitmap to the context. In addition, the bitmap
	 * is tinted with a given color.
	 *
	 * @param bitmap Bitmap to be rendered
	 * @param x x co-ordinate on screen
	 * @param y y co-ordinate on screen
	 * @param tintColor Color used to tint the bitmap
	 */
	public void renderBitmap(Bitmap bitmap, int x, int y, int tintColor) {
		renderBitmap(bitmap, x, y, 1.0f, tintColor);
	}

	/**
	 * Draws a given bitmap to the context. In addition, the bitmap
	 * has custom scaling and transparency.
	 *  
	 * @param bitmap Bitmap to be rendered
	 * @param x x co-ordinate on screen
	 * @param y y co-ordinate on screen
	 * @param alpha Transparency of the bitmap
	 * @param scale Custom scaling of the bitmap (1.0f is 1:1 ratio)
	 */
	public void renderBitmap(Bitmap bitmap, int x, int y, float alpha, float scale) {
		renderBitmap(bitmap, x, y, alpha, scale, 0);
	}
	
	/**
	 * Draws a given bitmap onto the context. In addition, the bitmap has
	 * custom transparency and color tinting. 
	 * 
	 * @param bitmap Bitmap to be rendered
	 * @param x x co-ordinate on screen
	 * @param y y co-ordinate on screen
	 * @param alpha Transparency of the bitmap
	 * @param tintColor Custom scaling of the bitmap (1.0f is 1:1 ratio)
	 */
	public void renderBitmap(Bitmap bitmap, int x, int y, float alpha, int tintColor) {
		renderBitmap(bitmap, x, y, alpha, 1.0f, tintColor);
	}

	/**
	 * Draws a given bitmap onto the context. In addition, the bitmap
	 * has custom scaling, transparency and color tinting.
	 * 
	 * @param bitmap Bitmap to be rendered
	 * @param x x co-ordinate on screen
	 * @param y y co-ordinate on screen
	 * @param alpha Transparency of the bitmap
	 * @param scale Scale factor of Bitmap (1.0f is 1:1 ratio)
	 * @param tintColor Custom scaling of the bitmap (1.0f is 1:1 ratio)
	 */
	public void renderBitmap(Bitmap bitmap, int x, int y, float alpha, float scale, int tintColor) {
		int startX = x;
		int startY = y;
		int endX = startX + bitmap.getWidth();
		int endY = startY + bitmap.getHeight();
		
		if(startX >= width || startY >= height || endX < 0 || endY < 0) return;
		if(startX < 0) startX = 0;
		if(startY < 0) startY = 0;
		if(endX > width) endX = width;
		if(endY > height) endY = height;
		
		for(int xx = startX; xx < endX; xx++) {
			for(int yy = startY; yy < endY; yy++) {
				int index = yy * width + xx;
				if(index < 0 || index > pixels.length - 1)
					continue;
				
				int bmpIndex = (yy - startY) * bitmap.getWidth() + (xx - startX);
				int pixel = bitmap.getPixels()[bmpIndex];
				int pixelAlpha = ((pixel >> 24) & 0xFF);
				if(pixelAlpha <= 0) continue;
				if(pixelAlpha != 255) {
					pixel = PixColor.tintPixelInt(pixels[index], pixel);
				}
				if(tintColor != 0) {
					pixel = PixColor.tintPixelInt(pixel, tintColor);
				}
				if(alpha < 1f) {
					int[] rgba = PixColor.fromPixelInt(pixel);
					pixel = PixColor.tintPixelInt(pixels[index], PixColor.toPixelInt(rgba[0], rgba[1], rgba[2], (int) (alpha * 255f)));
				}
				
				pixels[index] = pixel;
			}
		}
	}
	
	/**
	 * Fills a rectangle on-screen with a given color.
	 * 
	 * @param x x co-ordinate on screen
	 * @param y y co-ordinate on screen
	 * @param width Width of rectangle
	 * @param height Height of rectangle
	 * @param color Color of rectangle (Use <code>PixColor.toPixelInt()</code>
	 */
	public void renderFilledRectangle(int x, int y, int width, int height, int color) {
		int startX = x;
		int startY = y;
		int endX = startX + width;
		int endY = startY + height;
		
		if(startX < 0) startX = 0;
		if(startY < 0) startY = 0;
		if(endX > this.width) endX = this.width;
		if(endY > this.height) endY = this.height;
		if(startX >= this.width || startY >= this.height || endX < 0 || endY < 0) return;
		
		for(int xx = startX; xx < endX; xx++) {
			for(int yy = startY; yy < endY; yy++) {
				int index = yy * this.width + xx;
				if(index < 0 || index > pixels.length - 1) 
					continue;
				if(((color >> 24) & 0xFF) == 255) {
					pixels[index] = color;
				} else if(((color >> 24) & 0xFF) > 0) {
					pixels[index] = PixColor.tintPixelInt(pixels[index], color);
				}
			}
		}
	}
	
	/**
	 * Draws a rectangle on-screen with a given color.
	 * 
	 * @param x x co-ordinate on screen
	 * @param y y co-ordinate on screen
	 * @param width Width of rectangle
	 * @param height Height of rectangle
	 * @param color Color of rectangle (Use <code>PixColor.toPixelInt()</code>
	 */
	public void renderRectangle(int x, int y, int width, int height, int color) {
		int startX = x;
		int startY = y;
		int endX = startX + width;
		int endY = startY + height;
		if(startX >= this.width || startY >= this.height || endX < 0 || endY < 0) return;
		if(startX < 0) startX = 0;
		if(startY < 0) startY = 0;
		if(endX > this.width) endX = this.width;
		if(endY > this.height) endY = this.height;
		
		for(int xx = startX; xx < endX; xx++) {
			for(int yy = startY; yy < endY; yy++) {
				int index = yy * this.width + xx;
				if(index < 0 || index > pixels.length - 1) 
					continue;
				if(xx == startX || xx == endX - 1 || yy == startY || yy == endY - 1) {
					if(((color >> 24) & 0xFF) == 255) {
						pixels[index] = color;
					} else if(((color >> 24) & 0xFF) > 0) {
						pixels[index] = PixColor.tintPixelInt(pixels[index], color);
					}
				}
			}
		}
	}
	
	/**
	 * Draws a line of text to the screen. Additionally, the <pre>'\n'</pre> character can be
	 * used to switch to a new line.
	 * 
	 * @param text Text to be drawn on screen
	 * @param x x co-ordinate on screen
	 * @param y y co-ordinate on screen
	 */
	public void renderText(String text, int x, int y) {
		renderText(text, x, y, 0x00000000);
	}
	
	/**
	 * Draws a line of text to the screen with custom color.
	 * Additionally, the <pre>'\n'</pre> character can be used to switch to a new line.
	 * 
	 * @param text Text to be drawn on screen
	 * @param x x co-ordinate on screen
	 * @param y y co-ordinate on screen
	 * @param color Color of the text
	 */
	public void renderText(String text, int x, int y, int color) {
		renderText(text, x, y, color, 1.0f);
	}
	
	/**
	 * Draws a line of text to the screen with custom color and scaling.
	 * Additionally, the <pre>'\n'</pre> character can be used to switch to a new line.
	 * 
	 * @param text Text to be drawn on screen
	 * @param x x co-ordinate on screen
	 * @param y y co-ordinate on screen
	 * @param color Color of the text
	 * @param scale Custom scaling per glyph (1.0f is 1:1 ratio)
	 */
	public void renderText(String text, int x, int y, int color, float scale) {
		renderText(text, x, y, color, scale, 1.0f);
	}

	/**
	 * Draws a line of text to the screen with custom color, scaling and transparency.
	 * Additionally, the <pre>'\n'</pre> character can be used to switch to a new line.
	 * 
	 * @param text Text to be drawn on screen
	 * @param x x co-ordinate on screen
	 * @param y y co-ordinate on screen
	 * @param color Color of the text
	 * @param scale Custom scaling per glyph (1.0f is 1:1 ratio)
	 * @param alpha Alpha transparency of the text (between <pre>0f</pre> and <pre>1.0f</pre>
	 */
	public void renderText(String text, int x, int y, int color, float scale, float alpha) {
		if(font != null) {
			font.render(this, text, x, y, color, scale, alpha);
		}
	}

	/**
	 * Sets the color of a single pixel on the context.
	 * 
	 * @param x x co-ordinate on the screen
	 * @param y y co-ordinate on the screen
	 * @param color Color of the pixel (use <pre>PixColor.toPixelInt()</pre>)
	 */
	public void plotPixel(int x, int y, int color) {
		if(x < 0 || x > width - 1 || y < 0 || y >= height - 1) 
			return;
		if(((color >> 24) & 0xFF) == 255) {
			pixels[y * width + x] = color;
		} else if(((color >> 24) & 0xFF) > 0) {
			pixels[y * width + x] = PixColor.tintPixelInt(pixels[y * width + x], color);
		}
	}
	
	/**
	 * Sets the current font used for drawing text.
	 * 
	 * @param font Font used for drawing text
	 */
	public void setFont(@NotNull BitmapFont font) {
		this.font = font;
	}
	
	/**
	 * 
	 * @return The current font in use for drawing text. 
	 */
	public BitmapFont getFont() {
		return font;
	}
	
	/**
	 * 
	 * @return Pixel color data of the context
	 */
	public int[] getPixels() {
		return pixels;
	}
	
	/**
	 * 
	 * @return Current master image
	 */
	public BufferedImage getImage() {
		return image;
	}
	
	/**
	 * 
	 * @return Width of the context
	 */
	public int getWidth() {
		return width;
	}
	
	/**
	 * 
	 * @return Height of the context
	 */
	public int getHeight() {
		return height;
	}

	/**
	 * Sets the color used to clear last frame.
	 * Use <pre>PixColor.toPixInt()</pre>.
	 * 
	 * @param color Background clear color
	 */
	public void setClearColor(int color) {
		this.clearColor = color;
	}
}
