package me.nibby.pix;

/**
 * This is a game shutdown listener invoked on window closing. 
 * 
 * @author Kevin Yang
 */
public interface PixGameShutdownHook {

	/** Invoked on window closing */
	public void onGameClose(PixGame game);
	
}
