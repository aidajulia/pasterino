package me.nibby.pix;

import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;

import me.nibby.pix.util.Tuple2i;

/**
 *
 * @author James Roberts
 */
public class Input implements KeyListener, MouseListener, MouseMotionListener {

	/** Mouse left button index */
	public static final int MOUSE_LEFT = 1;
	
	/** Mouse middle button index */
    public static final int MOUSE_MIDDLE = 2;
    
    /** Mouse right button index */
    public static final int MOUSE_RIGHT = 3;

    private static final int NUM_MOUSE = 256;
    private static final int NUM_KEYCODES = 256;

    /** Current key state */
    private boolean[] currentKeys = new boolean[NUM_KEYCODES];
    
    /** Last key state */
    private boolean[] lastKeys = new boolean[NUM_KEYCODES];

    /** Location of the mouse relative to the window */
    private Tuple2i cursorPosition = new Tuple2i(0, 0);
    
    /** Current mouse state */
    private boolean[] currentMouse = new boolean[NUM_MOUSE];
    
    /** Mouse click state */
    private boolean[] clickedMouse = new boolean[NUM_MOUSE];
    
    private PixGame game;
    
    /**
     * Invoked automatically from <pre>PixGame</pre> when the instance is
     * being setup.
     * 
     * @param game Game engine instance
     */
    protected Input(PixGame game) {
    	this.game = game;
    }
    
    /**
     * Determines whether a mouse button is clicked
     * @param mouseButton Mouse button to investigate
     * @return Clicked state of mouse button
     */
    public boolean isMouseClicked(int mouseButton) {
        return clickedMouse[mouseButton];
    }

    /**
     * Determines whether a mouse button is being held down.
     * 
     * @param mouseButton Mouse button to investigate
     * @return true if mouse button is held down
     */
    public boolean isMouseDown(int mouseButton) {
        return currentMouse[mouseButton];
    }

    /**
     * Determines whether a key is being held down.
     * The values for the keys are retrieved from
     * <code>java.awt.event.KeyEvent</code>
     * 
     * @param keyCode Key to investigate
     * @return true if key is being held down
     */
    public boolean isKeyDown(int keyCode) {
        return currentKeys[keyCode];
    }

    /**
     * Determines a single key press.
     * The values for the keys are retrieved from
     * <code>java.awt.event.KeyEvent</code>
     *  
     * @param keyCode Key to investigate
     * @return true if key is pressed
     */
    public boolean isKeyPressed(int keyCode) {
        return !lastKeys[keyCode] && isKeyDown(keyCode);
    }

    /**
     * Retrieves the current position of the mouse cursor.
     * 
     * @return Current position of mouse cursor
     */
    public Tuple2i getCursorPosition() {
        return new Tuple2i(cursorPosition.x / game.getDrawScale(), cursorPosition.y / game.getDrawScale());
    }

    /**
     * Adjusts keyboard and mouse states
     */
    public void update() {
        for (int i = 0; i < NUM_KEYCODES; i++) lastKeys[i] = isKeyDown(i);
        for (int i = 0; i < NUM_MOUSE; i++) clickedMouse[i] = false;
    }

    @Override
    public void keyPressed(KeyEvent e) {
        currentKeys[e.getKeyCode()] = true;
    }

    @Override
    public void keyReleased(KeyEvent e) {
        currentKeys[e.getKeyCode()] = false;
    }

    @Override
    public void keyTyped(KeyEvent e) {
        lastKeys[e.getKeyCode()] = true;
    }

    @Override
    public void mousePressed(MouseEvent e) {
        currentMouse[e.getButton()] = true;
    }

    @Override
    public void mouseReleased(MouseEvent e) {
        currentMouse[e.getButton()] = false;
    }

    @Override
    public void mouseClicked(MouseEvent e) {
        clickedMouse[e.getButton()] = true;
    }

    @Override
    public void mouseMoved(MouseEvent e) {
        cursorPosition.x = e.getX() / game.getDrawScale();
        cursorPosition.y = e.getY() / game.getDrawScale();
    }

    //Unused
    @Override
    public void mouseEntered(MouseEvent e) {
    }

    @Override
    public void mouseExited(MouseEvent e) {
    }

    @Override
    public void mouseDragged(MouseEvent e) {
    }
    
    protected Input() {}
}
