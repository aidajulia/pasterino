package me.nibby.pix;

import java.awt.BorderLayout;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.ArrayList;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

/**
 * Encapsulates a game engine instance and provides the desktop GUI.
 * 
 * @author MrDeathJockey
 */
public class PixGameDesktopWrapper {

	/** Window in which the game canvas is laid */
	private JFrame container;
	
	/** Game engine instance */
	private PixGame game;
	
	/** Whether to show confirmation dialog before closing */
	private boolean promptExit = false;
	
	/** List of all shutdown listeners */
	private ArrayList<PixGameShutdownHook> shutdownHooks = new ArrayList<>();
	
	/**
	 * Creates a desktop window from an existing game instance.
	 * 
	 * @param game Game engine instance
	 */
	public PixGameDesktopWrapper(final PixGame game) {
		container = new JFrame();
		this.game = game;
		
		JPanel root = new JPanel(new BorderLayout());
		root.add(game, BorderLayout.CENTER);
		container.getContentPane().add(root);		
		container.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
		container.setResizable(false);
		container.setTitle(game.getTitle());
		container.pack();
		container.addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent e) {
				if(promptExit) {
					int response = JOptionPane.showConfirmDialog(container, "Are you sure you want to exit " + game.getTitle() + "?",
							"Confirm Exit", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
					if(response == JOptionPane.NO_OPTION) {
						return;						
					}
				}
				
				for(PixGameShutdownHook hook : shutdownHooks) {
					hook.onGameClose(game);
				}
				
				game.stop();
				container.dispose();
			}
		});
	}
	
	/**
	 * Toggles on-exit confirmation.
	 * 
	 * @param flag true if confirmation is needed
	 */
	public void setPromptExit(boolean flag) {
		this.promptExit = flag;
	}
	
	/**
	 * Registers a shutdown listener.
	 * 
	 * @param hook Shutdown listener
	 */
	public void addShutdownHook(PixGameShutdownHook hook) {
		this.shutdownHooks.add(hook);
	}
	
	/**
	 * Starts the game engine.
	 */
	public void launch() {
		container.setLocationRelativeTo(null);
		container.setVisible(true);
		game.start();
	}
}
