package me.nibby.pix;

import java.util.LinkedList;

import com.sun.istack.internal.NotNull;

/**
 * An animation is a series of Bitmaps played in a timed sequence.
 *
 * @author Kevin Yang
 */
public class Animation {

	/** Number of frames in the action */
	private LinkedList<Frame> frames = new LinkedList<>();

	/** Current frame being drawn */
	private int frame = -1;

	/** Is the action playing? */
	private boolean started = false;

	/** Relative speed to play the action in (original time * speed factor) */
	private float speed = 1f;

	/** Frame update timer */
	private long lastUpdate;

	/** Control for looping the action (i.e. start from beginning again when completed) */
	private boolean looping = false;

	/** Control for reversing the action (i.e. start from last frame of bitmap list) */
	private boolean reverseMode = false;

	/** Control for ping-pong mode (i.e. start from beginning but play reverse when last frame is reached, loop) */
	private boolean pingpongMode = false;

	/** Internal logic switch to initialize timers and variables on first update */
	private boolean firstUpdate = true;

	/**
	 * Creates an empty animation.
	 */
	public Animation() {}

	/**
	 * Creates an animation, assigning each frame with a delay time.
	 * The delay times must be the same size as the number of frames.
	 * 
	 * @param animation Series of frames to be played in order
	 * @param delayTimes Delay in millisecond for each frame
	 */
	public Animation(@NotNull Bitmap[] animation, @NotNull int[] delayTimes) {
		if(animation.length != delayTimes.length)
			throw new IllegalArgumentException("Animation frames and delay time length mismatch!");
		for(int i = 0; i < animation.length; i++) {
			frames.add(new Frame(animation[i], delayTimes[i]));
		}
	}

	/**
	 * Creates an animation, assigning all frames with a single delay time.
	 * 
	 * @param animation Series of frames to be played in order
	 * @param delay Delay in millisecond for each frame
	 */
	public Animation(@NotNull Bitmap[] animation, int delay) {
		for(int i = 0; i < animation.length; i++) {
			frames.add(new Frame(animation[i], delay));
		}
	}

	/**
	 * Adds a new frame to the end of the action list
	 * @param bitmap Bitmap to be drawn
	 * @param delay Time in milliseconds the frame lasts
	 * @return
	 */
	public Animation addFrame(Bitmap bitmap, int delay) {
		frames.add(new Frame(bitmap, delay));
		return this;
	}

	/**
	 * Renders the action on a given context.
	 *
	 * @param context Render context to be drawn on
	 * @param x x co-ordinate on screen
	 * @param y y co-ordinate on screen
	 */
	public void render(RenderContext context, int x, int y) {
		render(context, x, y, 1.0f);
	}

	/**
	 * Renders the action on a given context with specified transparency.
	 *
	 * @param context Render context to be drawn on
	 * @param x x co-ordinate on screen
	 * @param y y co-ordinate on screen
	 * @param alpha	Alpha transparency of the action
	 */
	public void render(RenderContext context, int x, int y, float alpha) {
		render(context, x, y, alpha, PixColor.toPixelInt(0, 0, 0, 0));
	}

	/**
	 * Renders the action on a given context with specified transparency and tint color.
	 *
	 * @param context Render context to be drawn on
	 * @param x x co-ordinate on screen
	 * @param y y co-ordinate on screen
	 * @param alpha	Alpha transparency of the action
	 * @param tintColor Tint color of the action
	 */
	public void render(RenderContext context, int x, int y, float alpha, int tintColor) {
		update();
		Frame f = frames.get(frame);
		context.renderBitmap(f.bitmap, x, y, alpha, tintColor);
	}

	/**
	 * Updates action timers and frame information
	 */
	private void update() {
		if(firstUpdate && !started) {
			start();
			firstUpdate = false;
		}

		if(started) {
			Frame f = frames.get(frame);
			int delay = (int) ((float) f.time * speed);
			if(System.currentTimeMillis() - lastUpdate > delay) {
				if(reverseMode) {
					frame--;
					if(frame < 0) {
						if(pingpongMode) {
							setReverseMode(false);
							frame++;
						} else if(looping) {
							frame = frames.size() - 1;
						} else {
							frame = 0;
							started = false;
						}
					}
				} else {
					frame++;
					if(frame > frames.size() - 1) {
						if(pingpongMode) {
							setReverseMode(true);
							frame--;
						} else if(looping) {
							frame = 0;
						} else {
							frame = frames.size() - 1;
							started = false;
						}
					}
				}
				lastUpdate = System.currentTimeMillis();
			}
		}
	}

	/**
	 * Flips all frames within the animation on one or more axis.
	 * 
	 * @param horizontal Flip all frames according to a horizontal axis
	 * @param vertical Flip all frames according to a vertical axis
	 */
	public void setFlipped(boolean horizontal, boolean vertical) {
		for(int i = 0; i < frames.size(); i++) {
			frames.get(i).bitmap = frames.get(i).bitmap.getFlipped(horizontal, vertical);
		}
	}

	/**
	 * Supplies the play speed of the animation. 
	 * 1f means normal speed, while 0.5f denotes half speed and 2.0f denotes 2x speed.
	 * 
	 * @return Play speed of the animation
	 */
	public float getSpeed() {
		return speed;
	}

	/**
	 * Changes the animation play speed. 1.0f is 1x speed.
	 * 
	 * @param speed Play speed of the animation
	 */
	public void setSpeed(float speed) {
		this.speed = speed;
	}

	/**
	 * Supplies the flag that denotes if the animation loops after finished playing.
	 * 
	 * @return Whether if animation loops after stopped playing
	 */
	public boolean isLooping() {
		return looping;
	}

	/**
	 * Sets whether the animation will loop after finished playing once. 
	 * 
	 * @param looping Whether animation loops after stopped playing once
	 */
	public void setLooping(boolean looping) {
		this.looping = looping;
	}

	/**
	 * Supplies whether the animation plays backwards.
	 * 
	 * @return Whether if animation plays backwards
	 */
	public boolean isReverseMode() {
		return reverseMode;
	}

	/**
	 * Sets whether animation will play backwards. 
	 * 
	 * @param reverseMode Flag that denotes backwards animation.
	 */
	public void setReverseMode(boolean reverseMode) {
		this.reverseMode = reverseMode;
	}

	/**
	 * Determines whether the animation is in ping-pong mode.
	 * Ping-pong mode animations will alter between reverse animation
	 * and normal animation each time after completing the animation sequence. 
	 * 
	 * @return Whether animation is in ping pong mode
	 */
	public boolean isPingpongMode() {
		return pingpongMode;
	}

	/**
	 * Sets whether animation will play in ping-pong mode.
	 * 
	 * @param pingpongMode Flag that denotes ping-pong mode.
	 */
	public void setPingpongMode(boolean pingpongMode) {
		this.pingpongMode = pingpongMode;
	}

	/**
	 * Begin playing action.
	 */
	public void start() {
		if(!started) {
			restart();
		}
	}

	/**
	 * Resets action timer to current time and frame to 0.
	 * Plays the action again if stopped.
	 */
	public void restart() {
		frame = 0;
		lastUpdate = System.currentTimeMillis();
		started = true;
	}

	/**
	 * Stops playing action.
	 */
	public void stop() {
		if(started) {
			lastUpdate = System.currentTimeMillis();
		}
	}

	/**
	 * Supplies the play state of the animation.
	 * 
	 * @return Play state of the animation. 
	 */
	public boolean hasStopped() {
		return !started;
	}

	/**
	 * A frame represents a Bitmap with a given duration time (in milliseconds).
	 */
	class Frame {

		private Bitmap bitmap;
		private int time;

		private Frame(Bitmap bitmap, int time) {
			this.bitmap = bitmap;
			this.time = time;
		}

	}

}