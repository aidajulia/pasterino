package me.nibby.pix;

import com.sun.istack.internal.NotNull;

import java.awt.*;
import java.awt.image.BufferedImage;
import java.awt.image.DataBufferInt;
import java.awt.image.VolatileImage;

/**
 * Bitmap is a representation of a region of pixel data as derived from a BufferedImage.
 * Assets (images) are loaded in the form of BufferedImage before translated into an array
 * integer representation of its pixel data. The render context then calculates the suitable
 * coordinate on-screen to render these.
 *
 * @author Kevin Yang
 */
public class Bitmap {

	/** Width of bitmap image */
	private int width;
	
	/** Height of bitmap image */
	private int height;
	
	/** Pixel color data */
	private int[] pixels;
	
	/** Original image representation of Bitmap */
	private BufferedImage image;
	
	/**
	 * Creates a deep clone of an existing bitmap.
	 * 
	 * @param bitmap Source bitmap to be cloned
	 */
	public Bitmap(Bitmap bitmap) {
		this.width = bitmap.width;
		this.height = bitmap.height;
		this.image = new BufferedImage(width, height, BufferedImage.TYPE_INT_ARGB);
		this.image.setRGB(0, 0, width, height, bitmap.getImage().getRGB(0, 0, width, height, null, 0, width), 0, width);
		this.pixels = ((DataBufferInt) image.getRaster().getDataBuffer()).getData();
	}
	
	/**
	 * Creates an empty bitmap of specified size.
	 * 
	 * @param w Width of bitmap
	 * @param h Height of bitmap
	 */
	public Bitmap(int w, int h) {
		this.width = w;
		this.height = h;
		this.image = new BufferedImage(w, h, BufferedImage.TYPE_INT_ARGB);
		this.pixels = ((DataBufferInt) image.getRaster().getDataBuffer()).getData();
	}
	
	/**
	 * Creates a bitmap from a sample BufferedImage. 
	 * All color data and other properties are then derived from this image.
	 * 
	 * @param image Sample BufferedImage
	 */
	public Bitmap(@NotNull BufferedImage image) {
		this.image = image;
		this.width = image.getWidth();
		this.height = image.getHeight();
		this.pixels = new int[width * height];
		this.pixels = ((DataBufferInt) image.getRaster().getDataBuffer()).getData();
	}
	
	/**
	 * Creates a bitmap from existing color data and given size.
	 * The BufferedImage respresentation will be generated from the color data.
	 * 
	 * @param pixels Color data
	 * @param w Width of the bitmap
	 * @param h Height of the bitmap
	 */
	public Bitmap(int[] pixels, int w, int h) {
		this.width = w;
		this.height = h;
		this.pixels = new int[w * h];
		this.image = new BufferedImage(width, height, BufferedImage.TYPE_INT_ARGB);
		image.setRGB(0, 0, width, height, pixels, 0, width);
		this.pixels = ((DataBufferInt) image.getRaster().getDataBuffer()).getData();
	}
	
	/**
	 * Generates a scaled version of this bitmap based on a scaling ratio.
	 * 
	 * @param scale Scaling ratio 
	 * @return
	 */
	public Bitmap getScaled(float scale) {
		return getScaled((int) ((float) width * scale), (int) ((float) height * scale));
	}
	
	/**
	 * Generates a scaled version of this bitmap based on a new given dimension.
	 * 
	 * @param width Width of scaled bitmap
	 * @param height Height of scaled bitmap
	 * @return
//	 */
	public Bitmap getScaled(int width, int height) {
		VolatileImage img = GraphicsEnvironment.getLocalGraphicsEnvironment()
				.getDefaultScreenDevice().getDefaultConfiguration()
				.createCompatibleVolatileImage(width, height, VolatileImage.TRANSLUCENT);
		Graphics2D g2d = img.createGraphics();
		g2d.setComposite(AlphaComposite.DstOut);
		g2d.setColor(new Color(0f, 0f, 0f, 0f));
		g2d.fillRect(0, 0, width, height);
		g2d.setComposite(AlphaComposite.Src);
		g2d.drawImage(image, 0, 0, width, height, null);
		g2d.dispose();
		BufferedImage result = new BufferedImage(width, height, BufferedImage.TYPE_INT_ARGB);
		result.setRGB(0, 0, width, height, img.getSnapshot().getRGB(0, 0, width, height, null, 0, width), 0, width);
		return new Bitmap(result);
	}
	
	/**
	 * Returns a region of pixels within the bitmap. The parameters
	 * define the bounds of the region.
	 *
	 * @param x0 Start X
	 * @param y0 Start Y
	 * @param x1 End X
	 * @param y1 End Y
	 * @return
	 */
	public int[] getPixels(int x0, int y0, int x1, int y1) {
		if(x1 <= x0 || y1 <= y0) 
			throw new IllegalArgumentException(String.format("x1 <= x0 or y1 <= y0! x0: %d, x1: %d | y0: %d, y1: %d", 
					x0, x1, y0, y1));
		if(x0 < 0 || x1 > width || y0 < 0 || y1 > height) 
			throw new IllegalArgumentException(String.format("Selected region out of bounds! x0: %d, x1: %d | y0: %d (width: %d), y1: %d (height: %d)", 
					x0, x1, y0, width, y1, height));
		int[] result = new int[(x1 - x0) * (y1 - y0)];
		for(int xx = x0; xx < x1; xx++) {
			for(int yy = y0; yy < y1; yy++) {
				result[(yy - y0) * (x1 - x0) + (xx - x0)] = pixels[xx + yy * width];
			}
		}
		return result;
	}
	
	/**
	 * Creates a transformed bitmap that has been flipping vertically or horizontally. 
	 * A copy of the pixel data is generated and the original is not affected by
	 * this method.
	 *
	 * @param horizontal Flag for flipping horizontally
	 * @param vertical Flag for flipping vertically
	 * @return A bitmap that is flipped by provided parameters
	 */
	public Bitmap getFlipped(boolean horizontal, boolean vertical) {
		if(!horizontal && !vertical) return this;
		int[] data = new int[getPixels().length];
		if(horizontal && !vertical) {
			for(int x = 0; x < getWidth(); x++) {
				for(int y = getHeight() - 1; y >= 0; y--) {
					data[(getHeight() - y - 1) * getWidth() + x] = pixels[y * getWidth() + x];
				}
			}
		} else if(vertical && !horizontal) {
			for(int x = getWidth() - 1; x >= 0; x--) {
				for(int y = 0; y < getHeight(); y++) {
					data[y * getWidth() + (getWidth() - x - 1)] = pixels[y * getWidth() + x];
				}
			}
		} else {
			for (int i = pixels.length - 1; i > 0; i--) {
				data[pixels.length - i] = pixels[i];
			}
		}
		return new Bitmap(data, width, height);
	}
	
	/**
	 * Returns a bitmap that is a smaller portion of the original. This is
	 * similar to 'getPixels(int x0, int y0, int x1, int y1)' but the result
	 * is wrapped in a Bitmap class for simplified use in RenderContext.
	 *
	 * The parameters specified define the bounds for the sub-bitmap.
	 *
	 * @param x0 Start X
	 * @param y0 Start Y
	 * @param x1 End X
	 * @param y1 End Y
	 * @see RenderContext
	 * @return A bitmap that is a portion of the original
	 */
	public Bitmap getRegionAsBitmap(int x0, int y0, int x1, int y1) {
		return new Bitmap(getPixels(x0, y0, x1, y1), x1 - x0, y1 - y0);
	}
	
	/**
	 * Supplies the width of this bitmap.
	 * 
	 * @return Width of the bitmap
	 */
	public int getWidth() {
		return width;
	}
	
	/**
	 * Supplies the height of this bitmap
	 * 
	 * @return Height of the bitmap
	 */
	public int getHeight() {
		return height;
	}
	
	/**
	 * Supplies the pixel data of this bitmap
	 * 
	 * @return Pixel data of the bitmap
	 */
	public int[] getPixels() {
		return pixels;
	}
	
	/**
	 * Supplies the original BufferedImage of this bitmap.
	 * 
	 * @return Original BufferedImage of the bitmap.
	 */
	public BufferedImage getImage() {
		return image;
	}
}
