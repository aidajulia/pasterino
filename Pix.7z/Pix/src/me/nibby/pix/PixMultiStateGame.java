package me.nibby.pix;

import java.util.HashMap;

import com.sun.istack.internal.Nullable;

public abstract class PixMultiStateGame extends PixGame {

	private static final long serialVersionUID = 1L;
	
	/** Game state registrar */
	private HashMap<Integer, PixGameState> gameStates = new HashMap<>();
	
	/** Current active game state */
	private PixGameState currentState;
	
	/** Next active game state (for transition) */
	private PixGameState nextState;
	
	/**
	 * Child classes are expected to register all game states in this method.
	 */
	public abstract void initializeGameStates();

	/**
	 * Creates a multi-state game with given game attributes.
	 * 
	 * @param name Name of the game
	 * @param width Width of game canvas
	 * @param height Height of game canvas
	 * @param scale Graphics scaling
	 */
	public PixMultiStateGame(String name, int width, int height, int scale) {
		super(name, width, height, scale);
		
		currentState = new PixGameState() {
			@Override
			public void gameInitialize() {
				
			}

			@Override
			public void gameUpdate(Input input, double delta) {
				
			}

			@Override
			public void gameRender(RenderContext c) {
				
			}

			@Override
			public int getStateID() {
				
				return -1;
			}
		};
		initializeGameStates();
	}
	
	/**
	 * Initializes current game state
	 */
	public void gameInitialize() {
		if(currentState != null) 
			currentState.gameInitialize();
	}
	
	/**
	 * Renders current active game state
	 * 
	 * @param context Render context used to draw state graphics
	 */
	public void gameRender(RenderContext context) {
		if(currentState != null) 
			currentState.gameRender(context);
	}
	
	/**
	 * Updates current active game state
	 * 
	 */
	public void gameUpdate(Input input, double delta) {
		if(currentState != null)
			currentState.gameUpdate(input, delta);
	}
	
	/**
	 * Switches current game state. 
	 * 
	 * @param id ID of next game state
	 */
	public void enterState(int id) {
		nextState = getState(id);
		if(nextState == null)
			throw new RuntimeException("No game state registered with ID: " + id);
		this.currentState = nextState;
		this.currentState.gameInitialize();
	}
	
	/**
	 * Adds a new state to the registrar.
	 * 
	 * @param state PixGameState to be added
	 */
	public void registerState(PixGameState state) {
		gameStates.put(state.getStateID(), state);
	}
	
	/**
	 * Supplies an existing state with provided ID.
	 * 
	 * @param stateID ID of existing state
	 * @return State that corresponds with the ID
	 */
	@Nullable
	public PixGameState getState(int stateID) {
		return gameStates.get(stateID);
	}
	
	/**
	 * Supplies the current active game state.
	 * 
	 * @return Current active game state
	 */
	public PixGameState getCurrentState() {
		return currentState;
	}
}
