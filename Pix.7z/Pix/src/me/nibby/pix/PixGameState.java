package me.nibby.pix;

/**
 * This is a game state used in conjunction with PixMultiStateGame.
 * It contains the abstract methods for game logic.
 * 
 * @author MrDeathJockey
 */
public abstract class PixGameState {
	
	/**
	 * Invoked after engine starts to initialize game objects.
	 */
	public abstract void gameInitialize();
	
	/**
	 * Invoked in game loop to update game logic.
	 *  
	 * @param input Input handler of the game engine
	 * @param delta Time in nanoseconds elapsed since last frame
	 */
	public abstract void gameUpdate(Input input, double delta);
	
	/**
	 * Invoked in game loop to render game objects.
	 * 
	 * @param c Render context on which objects are drawn
	 */
	public abstract void gameRender(RenderContext c);
	
	/**
	 * 
	 * @return Unique ID of this state
	 */
	public abstract int getStateID();
}
